/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package appfarmacia;

import Vistas.LoginForm;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      java.awt.EventQueue.invokeLater(() -> {
          new LoginForm().setVisible(true);  // Iniciar con la ventana de login
      });
    }
    
}
