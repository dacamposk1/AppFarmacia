/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vistas;

import Conexion.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author aguir
 */
public class CRUD {

    Conexion.ConexionBD con = new ConexionBD();
    Connection cx = con.getConnection();

    String run;
    String Pnombre;
    String Snombre;
    String Papellido;
    String Sapellido;
    String cargo;
    String contrasena;

    public String getRun() {
        return run;
    }

    public void setRun(String run) {
        this.run = run;
    }

    public String getPnombre() {
        return Pnombre;
    }

    public void setPnombre(String Pnombre) {
        this.Pnombre = Pnombre;
    }

    public String getSnombre() {
        return Snombre;
    }

    public void setSnombre(String Snombre) {
        this.Snombre = Snombre;
    }

    public String getPapellido() {
        return Papellido;
    }

    public void setPapellido(String Papellido) {
        this.Papellido = Papellido;
    }

    public String getSapellido() {
        return Sapellido;
    }

    public void setSapellido(String Sapellido) {
        this.Sapellido = Sapellido;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public void mostrarEmpleados(JTable paramtbEmpleados) {

        DefaultTableModel modelo = new DefaultTableModel();

        TableRowSorter<TableModel> ordenarTable = new TableRowSorter<TableModel>(modelo);
        paramtbEmpleados.setRowSorter(ordenarTable);

        String sql = "";

        modelo.addColumn("run");
        modelo.addColumn("nombre");
        modelo.addColumn("cargo");

        paramtbEmpleados.setModel(modelo);

        sql = "SELECT runEmpleado, CONCAT(pNombreEmpleado, ' ', sNombreEmpleado, ' ', pApellidoEmpleado, ' ', sApellidoEmpleado) AS nombreCompleto, idCargo FROM empleado";

        String[] datos = new String[3];
        Statement st;

        try {
            st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);

                modelo.addRow(datos);
            }
            paramtbEmpleados.setModel(modelo);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "no se pueden mostrar los empleados" + e.toString());
        }
    }

    public void SelecionarEmpleado(JTable paramEmpleados, JTextField Paramrun, JTextField ParamNombreCompleto) {

        try {
            int fila = paramEmpleados.getSelectedRow();

            if (fila >= 0) {
                String runSeleccionado = paramEmpleados.getValueAt(fila, 0).toString();
                Paramrun.setText(runSeleccionado);

                String nombreCompleto = paramEmpleados.getValueAt(fila, 1).toString();
                ParamNombreCompleto.setText(nombreCompleto);
            } else {
                JOptionPane.showMessageDialog(null, "empleado no seleccionado");
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error al seleccionar" + e.toString());

        }

    }

    /*public void  EliminarEmpleado(JTextField Prut){
        
        
   
        String consulta = "DELETE FROM empleado WHERE empleado.runEmpleado=?;";
        
        try {
            CallableStatement cs = con.conectar().prepareCall(consulta);
            cs.setString(1, getRun());
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "se elimino el empleado");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo eliminar el empleado"+e.toString());
        }
    }
}
     */
public void EliminarEmpleado(JTextField Prut) {

    String runEmpleado = Prut.getText();
    String consulta = "DELETE FROM empleado WHERE runEmpleado = ?";

    // Mostrar un cuadro de diálogo de confirmación
    int confirmacion = JOptionPane.showConfirmDialog(null, 
            "¿Estás seguro de que deseas eliminar al empleado con RUN: " + runEmpleado + "?", 
            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

    // Si el usuario confirma la eliminación
    if (confirmacion == JOptionPane.YES_OPTION) {
        try {
            Connection cx = con.getConnection();
            PreparedStatement ps = cx.prepareStatement(consulta);
            ps.setString(1, runEmpleado);
            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Se eliminó el empleado con RUN: " + runEmpleado);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró el empleado con RUN: " + runEmpleado);
            }

            ps.close();
            cx.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo eliminar el empleado: " + e.toString());
        }
    } else {
        // Si el usuario cancela la operación
        JOptionPane.showMessageDialog(null, "Eliminación cancelada");
    }
}

}
