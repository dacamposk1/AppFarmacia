/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vistas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Conexion.ConexionBD;  // Importa tu clase de conexión
import java.sql.ResultSet;
import javax.swing.JPasswordField;

/**
 *
 * @author Daniel
 */
public class Principal extends javax.swing.JFrame {

    private String cargo;  // Guardaremos el cargo del usuario
    private String runEmpleado;  // Guardaremos el RUN del usuario
    private String nombreCargo;  // Almacena el nombre del cargo
    public Principal(String cargo, String runEmpleado) {
        initComponents();
        setTitle("Farmacia San Sebastian");
        setLocationRelativeTo(null);
        this.cargo = cargo;  // Guardar el cargo en una variable de clase
        this.nombreCargo = nombreCargo;  
        this.runEmpleado = runEmpleado;  // Guardar el runEmpleado en una variable de clase

        // Mostrar un mensaje de bienvenida con el cargo del usuario
        JOptionPane.showMessageDialog(this, "Bienvenido. Tu rol es: " + cargo);
    }

    private void cambiarContrasena() {
        // Crear un campo de contraseña para solicitar la contraseña actual
        JPasswordField contrasenaActualField = new JPasswordField();
        int opcionActual = JOptionPane.showConfirmDialog(this, contrasenaActualField, "Ingresa tu contraseña actual:", JOptionPane.OK_CANCEL_OPTION);

        // Validar si el usuario hizo clic en "OK" y si la contraseña no está vacía
        if (opcionActual != JOptionPane.OK_OPTION || contrasenaActualField.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "Debes ingresar tu contraseña actual", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String contrasenaActual = new String(contrasenaActualField.getPassword());  // Convertir la contraseña actual a String

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Conectar a la base de datos para validar la contraseña actual
            ConexionBD conexion = new ConexionBD();
            conn = conexion.getConnection();

            // Consulta SQL para obtener la contraseña almacenada del usuario
            String query = "SELECT contrasena FROM Empleado WHERE runEmpleado = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, runEmpleado);  // Asignamos el RUN del empleado conectado

            rs = stmt.executeQuery();

            if (rs.next()) {
                String contrasenaAlmacenada = rs.getString("contrasena");

                // Validar si la contraseña ingresada coincide con la almacenada
                if (!contrasenaActual.equals(contrasenaAlmacenada)) {
                    JOptionPane.showMessageDialog(this, "La contraseña actual no es correcta", "Error", JOptionPane.ERROR_MESSAGE);
                    return;  // Si no coincide, detenemos el proceso
                }

                // Crear un campo de contraseña para la nueva contraseña
                JPasswordField nuevaContrasenaField = new JPasswordField();
                int opcionNueva = JOptionPane.showConfirmDialog(this, nuevaContrasenaField, "Ingresa tu nueva contraseña:", JOptionPane.OK_CANCEL_OPTION);

                // Validar si el usuario hizo clic en "OK" y si la nueva contraseña no está vacía
                if (opcionNueva != JOptionPane.OK_OPTION || nuevaContrasenaField.getPassword().length == 0) {
                    JOptionPane.showMessageDialog(this, "La nueva contraseña no puede estar vacía", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String nuevaContrasena = new String(nuevaContrasenaField.getPassword());  // Convertir la nueva contraseña a String

                // Actualizar la contraseña en la base de datos
                query = "UPDATE Empleado SET contrasena = ? WHERE runEmpleado = ?";
                stmt = conn.prepareStatement(query);
                stmt.setString(1, nuevaContrasena);  // Asignamos la nueva contraseña
                stmt.setString(2, runEmpleado);  // Asignamos el RUN del empleado conectado

                int filasActualizadas = stmt.executeUpdate();
                if (filasActualizadas > 0) {
                    JOptionPane.showMessageDialog(this, "Contraseña actualizada con éxito");
                } else {
                    JOptionPane.showMessageDialog(this, "Error al actualizar la contraseña", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } else {
                JOptionPane.showMessageDialog(this, "Error al validar la contraseña actual", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos manualmente
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void cerrarSesion() {
        int confirmacion = JOptionPane.showConfirmDialog(this, "¿Estás seguro de que deseas cerrar sesión?", "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            new LoginForm().setVisible(true);  // Volvemos al formulario de login
            this.dispose();  // Cerramos la ventana actual
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jCambiarContraseña = new javax.swing.JMenuItem();
        jMenuAdmEmpleados = new javax.swing.JMenuItem();
        jMenuItemRegistrar = new javax.swing.JMenuItem();
        jCerrarSesion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1012, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 554, Short.MAX_VALUE)
        );

        jMenu1.setText("Inventario etc (hay que ir añadiendo)");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Cuenta");

        jCambiarContraseña.setText("Cambiar Contraseña");
        jCambiarContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCambiarContraseñaActionPerformed(evt);
            }
        });
        jMenu2.add(jCambiarContraseña);

        jMenuAdmEmpleados.setText("Administrar Empleados");
        jMenuAdmEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuAdmEmpleadosActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuAdmEmpleados);

        jMenuItemRegistrar.setText("Registrar Empleado");
        jMenuItemRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemRegistrarActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItemRegistrar);

        jCerrarSesion.setText("Cerrar Sesión");
        jCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCerrarSesionActionPerformed(evt);
            }
        });
        jMenu2.add(jCerrarSesion);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCambiarContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCambiarContraseñaActionPerformed
        cambiarContrasena();
    }//GEN-LAST:event_jCambiarContraseñaActionPerformed

    private void jCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCerrarSesionActionPerformed
        cerrarSesion();  // Llamamos al método para cerrar sesión

    }//GEN-LAST:event_jCerrarSesionActionPerformed

    private void jMenuItemRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemRegistrarActionPerformed
        RegistrarEmpleado rg = new RegistrarEmpleado();
        rg.setVisible(true);
    }//GEN-LAST:event_jMenuItemRegistrarActionPerformed

    private void jMenuAdmEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuAdmEmpleadosActionPerformed
        if (cargo.equals("Admin")) { // Verifica si el rol es admin
            AdmUsuarios au = new AdmUsuarios();
            au.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "No tienes permiso para acceder a esta sección.", "Acceso Denegado", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jMenuAdmEmpleadosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            String idCargo = null;
            new Principal(idCargo).setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem jCambiarContraseña;
    private javax.swing.JMenuItem jCerrarSesion;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuItem jMenuAdmEmpleados;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItemRegistrar;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
